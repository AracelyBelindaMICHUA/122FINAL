function Publicidad() {
  return (
    <div className="text-center bg-warning p-2">
      PUBLICIDAD - Materia: Publicidad I
    </div>
  );
}

export default Publicidad;