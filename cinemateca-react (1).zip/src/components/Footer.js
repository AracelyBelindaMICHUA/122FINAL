function Footer() {
  return (
    <footer className="text-center bg-dark text-white p-2 mt-4">
      Desarrollado por: Juan Pérez
    </footer>
  );
}

export default Footer;